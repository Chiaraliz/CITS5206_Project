function WelcomeUser() {
  return <div className="text-l font-medium">Welcome, Liz.</div>;
}

export default WelcomeUser;

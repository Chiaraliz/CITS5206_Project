function Logo() {
  return (
    <div className="flex justify-center">
      <img
        className="h-32"
        src="/cropped-AASYP-Logo-FC-Transparent-300x170.webp"
      ></img>
    </div>
  );
}

export default Logo;

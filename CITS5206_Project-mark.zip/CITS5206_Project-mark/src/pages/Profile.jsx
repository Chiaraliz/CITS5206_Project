import UserInfoForm from "../features/profile/UserInfoForm";

function Profile() {
  return (
    <>
      <UserInfoForm />
    </>
  );
}

export default Profile;

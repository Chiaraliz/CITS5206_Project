function Subscription() {
  return <div>Subscription Page.</div>;
}

export default Subscription;

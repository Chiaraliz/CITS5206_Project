function Footer() {
  return (
    <div className="px-60 py-5 border-t shadow-sm text-sm">
      © 2023 ASEAN-Australia Strategic Youth Partnership Ltd
      <br /> ACN 631 871 184
    </div>
  );
}

export default Footer;
